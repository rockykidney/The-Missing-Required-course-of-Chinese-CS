# 课程名称

## 课程简介

- 所属大学：
- 先修要求：
- 编程语言：
- 课程难度：🌟🌟🌟
- 预计学时：

<!-- 用一两段话介绍这门课程，内容包括但不限于：
    （1）课程覆盖的知识点范围
    （2）与同类课程相比它的优势与特点
    （3）学习这门课程的体验与感受
    （4）自学这门课的注意点（踩过的坑、难度预警等等）
    （5）... ...
-->

## 课程资源

- 课程网站：
- 课程视频：
- 课程教材：
- 课程作业：

## 资源汇总

@XXX 在学习这门课中用到的所有资源和作业实现都汇总在 [user/repo - GitHub](https://github.com/user/repo) 中。

## 备注

编写文档时尽量遵守 [Markdown Rules][md_rules] 与 [Markdown 简体中文与西文混排要点][cn_en_mixed_typography]，前者可以通过 VS Code 插件 *markdownlint* 提示并处理。

[md_rules]: https://github.com/markdownlint/markdownlint/blob/master/docs/RULES.md
[cn_en_mixed_typography]: https://github.com/selfteaching/markdown-writing-with-mixed-cn-en

正文中请删除该节。
