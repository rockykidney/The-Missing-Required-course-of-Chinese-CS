# MIT: The Missing Semester of Your CS Education

## Descriptions

- Offered by: MIT
- Prerequisites: None
- Programming Languages: Shell
- Difficulty: 🌟🌟
- Class Hour: 10 hours

Just as the course name indicated, this course will teach the missing things in the university courses. It will cover shell programming, git, vim editor, tmux, ssh, sed, awk and even how to beautify your terminal. Trust me, this will be your first step to become a hacker!

## Resources

- Homepage: <https://missing.csail.mit.edu/>
- Records: <https://www.youtube.com/playlist?list=PLyzOVJj3bHQuloKGG59rS43e29ro7I57J>
- Assignments: Some exercises after each lecture.
