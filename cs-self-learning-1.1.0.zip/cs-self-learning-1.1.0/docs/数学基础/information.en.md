# MIT6.050J: Information theory and Entropy

## Descriptions

- Offered by: MIT
- Prerequisites: None
- Programming Languages: None
- Difficulty: 🌟🌟🌟
- Class Hour: 100 hours

This is MIT's introductory information theory course for freshmen, Professor Penfield has written a special [textbook](https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-050j-information-and-entropy-spring-2008/syllabus/MIT6_050JS08_textbook.pdf) for this course as course notes, which is in-depth and interesting.

## Course Resources

- Course Website: <https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-050j-information-and-entropy-spring-2008/index.htm>
- Textbook: <https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-050j-information-and-entropy-spring-2008/syllabus/MIT6_050JS08_textbook.pdf>
- Assignments: see the course website for details, including written assignments and Matlab programming assignments.
