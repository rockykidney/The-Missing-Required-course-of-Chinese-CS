# The Information Theory, Pattern Recognition, and Neural Networks

## 课程简介

- 所属大学：Cambridge
- 先修要求：Calculus, Linear Algebra, Probabilities and Statistics
- 编程语言：Anything would be OK, Python preferred
- 课程难度：🌟🌟🌟
- 预计学时：30-50 小时

剑桥大学 Sir David MacKay 教授的信息论课程。教授是一位十分精通信息论与神经网络的学者，课程对应教材也是信息论领域的一部经典著作。可惜天妒英才...

## 课程资源

- 课程网站：<http://www.inference.org.uk/mackay/itila/>
- 课程视频：<https://www.bilibili.com/video/BV1rs411T71e>
- 课程教材：Information Theory, Inference, and Learning Algorithms 在课程网站可以下载到免费的电子版
- 课程作业：在每一节课视频的最后会留教材上的课后习题

## R.I.P Prof. David MacKay
