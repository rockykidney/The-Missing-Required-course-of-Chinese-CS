# MIT 6.007 Signals and Systems

## 课程简介

- 所属大学：MIT
- 先修要求：Calculus, Linear Algebra
- 编程语言：Matlab Preferred
- 课程难度：🌟🌟
- 预计学时：50-70 小时

看到课程老师的名字：Prof. Alan V. Oppenheim

好的，上这门课的理由已经足够了。

## 课程资源

- 课程网站：<https://ocw.mit.edu/resources/res-6-007-signals-and-systems-spring-2011/index.htm>
- 课程视频：<https://www.bilibili.com/video/BV1CZ4y1j7hs>
- 课程教材：Signals and Systems, 2nd Edition
- 课程作业：<https://ocw.mit.edu/resources/res-6-007-signals-and-systems-spring-2011/assignments>
