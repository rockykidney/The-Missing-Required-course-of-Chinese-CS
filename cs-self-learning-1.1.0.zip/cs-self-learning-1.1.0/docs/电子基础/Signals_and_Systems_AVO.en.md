# MIT 6.007 Signals and Systems

## Descriptions

- Offered by: MIT
- Prerequisites: Calculus, Linear Algebra
- Programming Languages: Matlab Preferred
- Difficulty: 🌟🌟
- Class Hour: 50-70 hours

The name of the instructor: Prof. Alan V. Oppenheim

Okay, enough reason to take this class.

## Course Resources

- Course Website: <https://ocw.mit.edu/resources/res-6-007-signals-and-systems-spring-2011/index.htm>
- Recordings: <https://www.bilibili.com/video/BV1CZ4y1j7hs>
- Textbooks: Signals and Systems, 2nd Edition
- Assignments: <https://ocw.mit.edu/resources/res-6-007-signals-and-systems-spring-2011/assignments>
