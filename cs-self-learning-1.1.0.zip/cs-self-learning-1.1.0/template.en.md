# Course Code: Course Name

## Descriptions

- Offered by:
- Prerequisites:
- Programming Languages:
- Difficulty: 🌟🌟🌟
- Class Hour:

<!-- 
        Introduce the course in a paragraph or two, including but not limited to:
        (1) The technical knowledge covered in lectures
        (2) Its differences and features compared to similar courses
        (3) Your personal experiences and feelings after studying this course
        (4) Caveats about studying this course on your own (pitfalls, difficulty warnings, etc.)
        (5) ... ...
-->

## Course Resources

- Course Website:
- Recordings:
- Textbooks:
- Assignments:

## Personal Resources

All the resources and assignments used by @XXX in this course are maintained in [user/repo - GitHub](https://github.com/user/repo).
